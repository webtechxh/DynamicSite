module.exports = {
  secret: 'sadnjklh82ffdafdd4321a43sfdsag5w4gyurn63f90489'
}
